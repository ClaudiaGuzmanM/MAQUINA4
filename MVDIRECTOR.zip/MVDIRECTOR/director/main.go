package main

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	pb "github.com/EdwardFlowersGg/Lab4_INF-343/proto"
	"github.com/streadway/amqp"
	"google.golang.org/grpc"
)

// Definición del struct Mercenario
type server struct {
	pb.UnimplementedKFserviceServer
	MercenariosPiso1, MercenariosPiso2, MercenariosPiso3 []Mercenario
	Estado, Final                                        bool
	Piso, X, Y, directorMov, patriarcaNum                int32
	FinalOps, Ronda                                      int
	mu                                                   sync.Mutex
}

type Mercenario struct {
	ID     int32
	Nombre string
	Piso   int32
	Move   int32
	Ronda  int32
}

// LOCAL
func failOnError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s", msg, err)
	}
}

func (s *server) eliminarMercenario(id int32, piso int32) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var mercenarios *[]Mercenario
	switch piso {
	case 1:
		mercenarios = &s.MercenariosPiso1
	case 2:
		mercenarios = &s.MercenariosPiso2
	case 3:
		mercenarios = &s.MercenariosPiso3
	default:
		fmt.Printf("Piso no válido: %d\n", piso)
		return
	}

	for i, m := range *mercenarios {
		if m.ID == id {
			*mercenarios = append((*mercenarios)[:i], (*mercenarios)[i+1:]...)
			fmt.Printf("\nEl mercenario %s ha sido eliminado del piso %d\n", m.Nombre, piso)

			// Send message to Dosh Bank
			sendToDoshBank(m.Nombre, piso, 1000) // Assume 1000 is the amount, replace with actual value if needed
			break
		}
	}
}

func (s *server) EnviarDatos(mercenario *Mercenario) {
	s.mu.Lock()
	defer s.mu.Unlock()
	
	// Establecer una conexión con el servidor de NameNode.
	conn, err := grpc.Dial("localhost:8085", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("Error al conectar: %v", err)
	}
	defer conn.Close()
	client := pb.NewKFserviceClient(conn)
	response, err := client.SolicitarRegistroDataName(context.Background(), &pb.RegistroDataNameRequest{
		ID:     mercenario.ID,
		Nombre: mercenario.Nombre,
		Piso:   mercenario.Piso,
		Mov:    mercenario.Move,
	})
	if err != nil {
		log.Fatalf("Error al enviar datos al NameNode: %v", err)
	}
	if response.Success {
		fmt.Printf("Datos del mercenario %s enviados al NameNode\n", mercenario.Nombre)
	}
}

func sendToDoshBank(name string, floor int32, amount int64) {
	// Establecer una conexión con RabbitMQ usando el protocolo AMQP y las credenciales predeterminadas.
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
	failOnError(err, "Failed to connect to RabbitMQ")
	// Asegurarse de cerrar la conexión al finalizar la función.
	defer conn.Close()

	// Crear un canal en la conexión establecida.
	ch, err := conn.Channel()
	failOnError(err, "Failed to open a channel")
	// Asegurarse de cerrar el canal al finalizar la función.
	defer ch.Close()

	// Declarar una cola en RabbitMQ con las siguientes características:
	// nombre: "mercenary_eliminations", durable: true, delete when unused: false,
	// exclusive: false, no-wait: false, sin argumentos adicionales.
	q, err := ch.QueueDeclare(
		"mercenary_eliminations", // nombre de la cola
		true,                     // durable (la cola sobrevivirá a reinicios del servidor)
		false,                    // delete when unused (no se borrará cuando no esté en uso)
		false,                    // exclusive (no es exclusiva para esta conexión)
		false,                    // no-wait (esperar a que la cola esté declarada)
		nil,                      // arguments (sin argumentos adicionales)
	)
	failOnError(err, "Failed to declare a queue")

	// Formatear el mensaje que se va a enviar a la cola con el nombre, piso y monto del mercenario.
	message := fmt.Sprintf("%s %d %d", name, floor, amount)
	// Publicar el mensaje en la cola declarada.
	err = ch.Publish(
		"",     // exchange (usar el exchange predeterminado)
		q.Name, // routing key (nombre de la cola)
		false,  // mandatory (si es true, devolverá un error si no se puede enrutar el mensaje)
		false,  // immediate (si es true, devolverá un error si el mensaje no puede ser entregado de inmediato)
		amqp.Publishing{
			ContentType: "text/plain",    // tipo de contenido del mensaje
			Body:        []byte(message), // cuerpo del mensaje
		})
	failOnError(err, "Failed to publish a message")
}

func (s *server) MostrarMercenarios(piso int32) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var mercenarios []Mercenario
	switch piso {
	case 1:
		mercenarios = s.MercenariosPiso1
	case 2:
		mercenarios = s.MercenariosPiso2
	case 3:
		mercenarios = s.MercenariosPiso3
	default:
		fmt.Printf("Piso no válido: %d\n", piso)
		return
	}

	fmt.Printf("Mercenarios vivos en el piso %d:\n", piso)
	for _, mercenario := range mercenarios {
		fmt.Printf("ID: %d, Nombre: %s\n", mercenario.ID, mercenario.Nombre)
	}
}

func verHistorialJugador() {
    var idStr, nombre, pisoStr string
    fmt.Print("Ingrese el ID del jugador: ")
    fmt.Scanln(&idStr)
    fmt.Print("Ingrese el nombre del jugador: ")
    fmt.Scanln(&nombre)
    fmt.Print("Ingrese el piso del jugador: ")
    fmt.Scanln(&pisoStr)

    id, err := strconv.Atoi(idStr)
    if err != nil {
        fmt.Println("ID no válido. Debe ser un número.")
        return
    }
    piso, err := strconv.Atoi(pisoStr)
    if err != nil {
        fmt.Println("Piso no válido. Debe ser un número.")
        return
    }

    // Conectar al servidor gRPC y solicitar el historial del jugador
    conn, err := grpc.Dial("localhost:8085", grpc.WithInsecure())
    if err != nil {
        fmt.Printf("Error al conectar con el servidor gRPC: %v\n", err)
        return
    }
    defer conn.Close()

    client := pb.NewKFserviceClient(conn)
    req := &pb.HistorialRequest{
        ID:     int32(id),
        Nombre: nombre,
        Piso:   int32(piso),
    }
    resp, err := client.SolicitarHistorialNameNode(context.Background(), req)
    if err != nil {
        fmt.Printf("Error al solicitar el historial del jugador: %v\n", err)
        return
    }

    fmt.Printf("Historial del Jugador ID: %d, Piso: %d\n", id, piso)
    fmt.Printf("Nombre: %s, Movimiento más reciente: %d\n", resp.Nombre, resp.Mov)
    fmt.Println("Historial de movimientos:")
    for _, elem := range resp.Elementos {
        fmt.Println(elem)
    }
}

// REMOTOO
// Definición de la función SolicitarEntrarPiso
func (s *server) SolicitarEntrarPiso(ctx context.Context, req *pb.EntrarPisoRequest) (*pb.EntrarPisoResponse, error) {
	// Guardar los datos en el struct Mercenario y agregarlo a la lista correspondiente
	var success bool
	mercenario := Mercenario{
		Ronda:  req.Estado,
		ID:     req.ID,
		Nombre: req.Nombre,
		Piso:   req.Piso,
	}
	success = s.Piso == req.Piso && s.Ronda == int(req.Estado)

	// Enviar la respuesta y terminar la ejecución de la función
	if success {
		if s.Ronda == 1 {
			fmt.Println("  ")
			fmt.Printf("El mercenario %s ha entrado al piso %d\n", req.Nombre, req.Piso)
			fmt.Println("Preesione cualquier tecla para continuar...")
		} else {
			if s.Ronda != 6 {
				fmt.Println("  ")
				fmt.Printf("El mercenario %s esta listo para la ronda %d\n", req.Nombre, req.Estado)
				fmt.Println("Preesione cualquier tecla para continuar...")
			}
		}
		switch req.Piso {
		case 1:
			s.MercenariosPiso1 = append(s.MercenariosPiso1, mercenario)
		case 2:
			s.MercenariosPiso2 = append(s.MercenariosPiso2, mercenario)
		case 3:
			if s.Ronda == 1 {
				s.MercenariosPiso3 = append(s.MercenariosPiso3, mercenario)
			}
		default:
			return nil, fmt.Errorf("piso no válido")
		}
	}
	return &pb.EntrarPisoResponse{Success: success}, nil
}

func (s *server) SolicitarMontoDineroMercenarioDirector(ctx context.Context, in *pb.MontoDineroMercenarioDirectorRequest) (*pb.MontoDineroResponse, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	conn, err := grpc.Dial("localhost:8080", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("Error al conectar: %v", err)
	}
	defer conn.Close()
	client := pb.NewKFserviceClient(conn)
	response, err := client.SolicitarMontoDineroDirectorBanco(context.Background(), &pb.MontoDineroDirectorBancoRequest{})
	if err != nil {
		log.Fatalf("Error al solicitar monto al director del banco: %v", err)
	}
	return &pb.MontoDineroResponse{Amount: response.Amount}, nil

}

func (s *server) SolicitarMovimiento(ctx context.Context, req *pb.MovimientoRequest) (*pb.MovimientoResponse, error) {
	var success bool
	mercenario := Mercenario{
		ID:     req.ID,
		Nombre: req.Nombre,
		Piso:   req.Piso,
		Move:   req.Mov,
	}

	switch req.Piso {
	case 1:
		success = s.calcularProbabilidad(req.Mov)
	case 2:
		// Piso 2: Trampas y Traiciones
		success = s.verificarTrampa(req.Mov)
	case 3:
		// Piso 3: Confrontación Final
		success = s.confrontacionFinal(req.Mov)
		s.mu.Lock()
		s.FinalOps++
		s.mu.Unlock()
		return &pb.MovimientoResponse{Success: success}, nil

	default:
		return nil, fmt.Errorf("piso no válido")
	}

	// Si el mercenario no sobrevive, mostrar mensaje y eliminarlo del array
	if !success {
		fmt.Printf("El mercenario %s ha muerto en el piso %d\n", req.Nombre, req.Piso)
		go s.eliminarMercenario(req.ID, req.Piso)
	}
	s.mu.Lock()
	s.FinalOps++
	s.mu.Unlock()
	s.EnviarDatos(&mercenario)
	return &pb.MovimientoResponse{Success: success}, nil
}

func (s *server) SolicitarResultado(ctx context.Context, req *pb.JugarRequest) (*pb.JugarResponse, error) {
	if s.Estado {
		return &pb.JugarResponse{Success: true}, nil
	} else {
		return &pb.JugarResponse{Success: false}, nil
	}
}

func (s *server) SolicitarFinal(ctx context.Context, req *pb.FinalRequest) (*pb.FinalResponse, error) {
	if s.Final {
		if !req.Success {
			go s.eliminarMercenario(req.ID, int32(3))
		}
		s.FinalOps++
		return &pb.FinalResponse{Success: true}, nil
	} else {
		return &pb.FinalResponse{Success: false}, nil
	}

}

// Función para calcular la probabilidad de éxito en el piso 1.
func (s *server) calcularProbabilidad(mov int32) bool {
	// Cálculo de probabilidades
	
	var probabilidad1, probabilidad2, probabilidad3 int32
	if s.X < s.Y {
		probabilidad1 = s.X
		probabilidad2 = s.Y - s.X
		probabilidad3 = 100 - s.Y
	} else {
		probabilidad1 = s.Y
		probabilidad2 = s.X - s.Y
		probabilidad3 = 100 - s.X
	}

	// Selección del movimiento y verificación de la supervivencia del mercenario.
	aux := rand.Int31n(100) + 1
	switch mov {
	case 1:
		return (aux <= probabilidad1) // Escopeta
	case 2:
		return (aux >= probabilidad1 && aux <= probabilidad1+probabilidad2) // Rifle automático
	case 3:
		return (aux >= probabilidad1+probabilidad2 && aux <= probabilidad3+probabilidad1+probabilidad2) // Puños eléctricos
	default:
		return false
	}
}

// Función para verificar la trampa en el piso 2.
func (s *server) verificarTrampa(mov int32) bool {
	// Verificación de la elección del mercenario.
	return mov == s.directorMov
}

// Función para la confrontación final en el piso 3.
func (s *server) confrontacionFinal(mov int32) bool {
	// Verificación de la elección del mercenario.
	return mov == s.patriarcaNum
}

func main() {
	rand.Seed(time.Now().UnixNano()) // Inicializar el generador de números aleatorios

	s := grpc.NewServer()
	serv := &server{Piso: 1} // Inicia el servidor en el piso 1
	pb.RegisterKFserviceServer(s, serv)

	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("Error al escuchar: %v", err)
	}

	go func() {
		if err := s.Serve(lis); err != nil {
			log.Fatalf("Failed to serve: %v", err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	var mercenarios []Mercenario
	serv.Ronda = 1
	serv.Final = false
	for {
		if serv.Ronda == 6 {
			mercenarios = serv.MercenariosPiso3
			serv.Final = true
			for serv.FinalOps != len(mercenarios) {
				fmt.Printf("\nOperaciones finalizadas: %d\n", serv.FinalOps)
				fmt.Printf("Mercenarios en el piso %d: %d\n", serv.Piso, len(mercenarios))
				fmt.Println("Esperando resultados finales")
				time.Sleep(3 * time.Second)
			}
			fmt.Println("¡Juego finalizado!")
			fmt.Println("Ganadores:")
			serv.MostrarMercenarios(serv.Piso)
			s.GracefulStop()
			return
		}
		fmt.Printf("Piso actual del servidor: %d\n", serv.Piso)
		fmt.Printf("Ronda actual: %d\n", serv.Ronda)
		fmt.Println("----------------------------")
		fmt.Println("Opciones:")
		fmt.Println("1. Iniciar Juego")
		fmt.Println("2. Mostrar Jugadores con vida")
		fmt.Println("3. Ver historial de un jugador")
		fmt.Println("4. Salir")
		select {
		case <-stop:
			fmt.Println("\nSaliendo del servidor...")
			s.GracefulStop()
			return
		default:
			var input string
			fmt.Print("\nIngrese su opción: ")
			fmt.Scanln(&input)

			switch strings.TrimSpace(input) {
			case "1":
				switch serv.Piso {
				case 1:
					fmt.Println("¡Iniciando juego en el piso 1!")
					mercenarios = serv.MercenariosPiso1
					// Generar dos números enteros aleatorios distintos para X y Y
					serv.X = rand.Int31n(100) + 1 // Número entre 1 y 100
					serv.Y = rand.Int31n(100) + 1 // Número entre 1 y 100
					for serv.X == serv.Y {
						serv.Y = rand.Int31n(100) + 1 // Asegurarse de que Y sea distinto de X
					}
					fmt.Printf("Generados X: %d y Y: %d\n", serv.X, serv.Y)
				case 2:
					mercenarios = serv.MercenariosPiso2
					fmt.Println("¡Iniciando juego en el piso 2!")
					// Generar un número entero entre 1 y 2 para directorMov
					serv.directorMov = rand.Int31n(2) + 1
					fmt.Printf("Generado directorMov: %d\n", serv.directorMov)
				case 3:
					mercenarios = serv.MercenariosPiso3
					fmt.Printf("¡Iniciando juego en el piso 3 ronda : %d!", serv.Ronda)
					// Generar un número entero entre 1 y 15 para patriarcaNum
					serv.patriarcaNum = rand.Int31n(15) + 1
					fmt.Printf("Generado patriarcaNum: %d\n", serv.patriarcaNum)
				}
				if len(mercenarios) == 1 {
					serv.Final = true
					fmt.Println("¡Juego finalizado!")
					fmt.Println("Ganador:")
					serv.MostrarMercenarios(serv.Piso)
					s.GracefulStop()
					return

				}
				serv.Estado = true
				for serv.FinalOps != len(mercenarios) {
					fmt.Printf("\nOperaciones finalizadas: %d\n", serv.FinalOps)
					fmt.Printf("Mercenarios en el piso %d: %d\n", serv.Piso, len(mercenarios))
					fmt.Println("Esperando movimientos de jugadores")
					time.Sleep(3 * time.Second)
				}
				serv.Estado = false
				serv.FinalOps = 0
				serv.MostrarMercenarios(serv.Piso)
				if serv.Piso == 3 {
					serv.Ronda++
				} else {
					serv.Piso++
				}
			case "2":
				fmt.Println("Mostrando Jugadores...")
				serv.MostrarMercenarios(serv.Piso)
			case "3":
				verHistorialJugador()
			case "4":
				fmt.Println("Saliendo del servidor...")
				s.GracefulStop()
				return
			default:
				fmt.Println("Opción no válida. Por favor, ingrese 1, 2, 3 o 4.")
			}
		}
	}
}
