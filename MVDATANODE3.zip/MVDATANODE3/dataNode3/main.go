package main

import (
	"bufio"
	"context"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"sync"

	pb "github.com/EdwardFlowersGg/Lab4_INF-343/proto"
	"google.golang.org/grpc"
)

const (
	port = ":50055" // Puerto donde escucha el DataNode
)

type server struct {
	pb.UnimplementedKFserviceServer // Embebiendo la estructura
	mutex                           sync.Mutex
}

func (s *server) SolicitarRegistrNodo(ctx context.Context, req *pb.RegistroNodoRequest) (*pb.RegistroNodoResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	record := fmt.Sprintf("%d", req.Mov)

	// Registrar la decisión en un archivo
	fileName := fmt.Sprintf("dataNode3/%s_%d.txt", req.Nombre, req.Piso)
	file, err := os.OpenFile(fileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return &pb.RegistroNodoResponse{Success: false}, err
	}
	defer file.Close()

	if _, err := file.WriteString(record + "\n"); err != nil {
		return &pb.RegistroNodoResponse{Success: false}, err
	}

	return &pb.RegistroNodoResponse{Success: true}, nil
}

func (s *server) SolicitarHistorialDataNode(ctx context.Context, req *pb.HistorialRequest) (*pb.HistorialResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	fileName := fmt.Sprintf("dataNode/%s_%d.txt", req.Nombre, req.Piso)
	file, err := os.Open(fileName)
	if err != nil {
		return nil, fmt.Errorf("error al abrir el archivo: %w", err)
	}
	defer file.Close()

	var elementos []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		elementos = append(elementos, scanner.Text())
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error al leer el archivo: %w", err)
	}

	// Aquí asumimos que el último movimiento es el más reciente
	mov := 0
	if len(elementos) > 0 {
		mov, err = strconv.Atoi(elementos[len(elementos)-1])
		if err != nil {
			return nil, fmt.Errorf("error al convertir el último movimiento: %w", err)
		}
	}

	return &pb.HistorialResponse{
		ID:        req.ID,
		Nombre:    req.Nombre,
		Mov:       int32(mov),
		Elementos: elementos,
	}, nil
}

func main() {
	lis, err := net.Listen("tcp", port)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterKFserviceServer(s, &server{})
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
